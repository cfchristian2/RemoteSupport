//
//  RemoteSupport.h
//  RemoteSupport
//
//  Created by Conner Christianson on 1/31/20.
//  Copyright © 2020 i3pd. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for RemoteSupport.
FOUNDATION_EXPORT double RemoteSupportVersionNumber;

//! Project version string for RemoteSupport.
FOUNDATION_EXPORT const unsigned char RemoteSupportVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RemoteSupport/PublicHeader.h>

