# RemoteSupport

1. Build framework for generic mobile
2. Build framework for simulator
3. lipo -create mobile/RemoteSupport.framework/RemoteSupport sim/RemoteSupport.framework/RemoteSupport -output RemoteSupport.framework/RemoteSupport
