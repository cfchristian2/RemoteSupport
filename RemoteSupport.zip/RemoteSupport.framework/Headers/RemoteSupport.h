//
//  RemoteSupport.h
//  RemoteSupport
//
//  Created by Conner Christianson on 9/13/19.
//  Copyright © 2019 i3pd. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for RemoteSupport.
FOUNDATION_EXPORT double RemoteSupportVersionNumber;

//! Project version string for RemoteSupport.
FOUNDATION_EXPORT const unsigned char RemoteSupportVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RemoteSupport/PublicHeader.h>


